//
//  ContentView.swift
//  TreeHacks25App
//
//  Created by ajapps on 2/15/25.
//

import SwiftUI
import TerraRTiOS
import BackgroundTasks

struct BluetoothScanView: View {
    @State private var showScanWidget = false
    @State private var scanSuccess = false
    @State private var terraRT: TerraRT?
    @State private var isConnected = false
    @State private var lastUploadTime: Date = Date()
    @State private var sleepData: [String: Any] = [:]
    @AppStorage("lastProcessedData") private var lastProcessedDataTimeStamp: Double = Date().timeIntervalSince1970
    
    
    var body: some View {
        VStack {
            if !isConnected {
                Text("Waiting for connection...")
                    .foregroundColor(.orange)
            } else {
                Text("Connected!")
                    .foregroundColor(.green)
                // Add status text for the data you're receiving
                // No need for bluetooth scanning since we're using Watch
            }
        }
        .padding()
        .onAppear {
            setupTerraRT()
        }
    }
    
    func initializeConnection() {
        print("Starting connection initialization...")
        let token = "54677c3b3893f0ff58a47c10bee4c5ca2910ab5114f352c41e00c8e9a5f2e1aa"
        terraRT?.initConnection(token: token) { success in
            print("Connection initialization callback received: \(success)")
            if success {
                print("Connection initialized successfully!")
                DispatchQueue.main.async {
                    isConnected = true
                    startScan() // Automatically start scan after successful connection
                }
            } else {
                print("Failed to initialize connection.")
                DispatchQueue.main.async {
                    isConnected = false
                }
            }
        }
    }
    
    
    func setupTerraRT() {
        print("Starting TerraRT setup...")
        terraRT = TerraRT(devId: "4actk-treehacks25-testing-xhheRBz5Kj", referenceId: "sampleUserReferenceId") { success in
            print("TerraRT initialization callback received: \(success)")
            if success {
                print("TerraRT initialization successful!")
                initializeConnection()
                setupWatchOSConnection()
                setupBackgroundProcessing()
            } else {
                print("TerraRT initialization failed.")
            }
        }
    }
    
    private func setupWatchOSConnection() {
            do {
                try terraRT?.connectWithWatchOS() // Add try
            } catch {
                print("Failed to connect with watchOS: \(error)")
            }
            listenForDataFromWatch()
        }
    
    func listenForDataFromWatch() {
        
//            let dataTypes: Set<DataTypes> = [.HEART_RATE, .STEPS]
//        terraRT?.startRealtime(type: .WATCH_OS, dataTypes: dataTypes) { update in
//                print("Received update from watchOS: \(update)")
//            }
    }

    private func handleWatchData(_ update: Any) {
            guard let data = update as? [String: Any] else { return }
            
            // Process and batch data
            let currentTime = Date()
            let timeSinceLastUpload = currentTime.timeIntervalSince(lastUploadTime)
            
            // Upload every 15 minutes or when sleep data is received
            if timeSinceLastUpload >= 900 || data["sleep"] != nil {
                uploadToServer(data: data)
                lastUploadTime = currentTime
            }
    }
    
    private func uploadToServer(data: [String: Any]) {
        // Configure your server endpoint
        guard let url = URL(string: "SERVER_ENDPOINT") else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: data)
            request.httpBody = jsonData
            
            URLSession.shared.dataTask(with: request) { data, response, error in
                if let error = error {
                    print("Upload error: \(error)")
                    return
                }
                
                if let data = data,
                   let serverResponse = try? JSONSerialization.jsonObject(with: data) {
                    // handle response after POST request.
                    
                }
            }.resume()
        } catch {
            print("JSON serialization error: \(error)")
        }
    }
    
    private func setupBackgroundProcessing() {
            // Use Timer for periodic updates while app is active
            Timer.scheduledTimer(withTimeInterval: 900, repeats: true) { _ in
                // Perform periodic processing
                print("Performing periodic background processing")
            }
        }
    
    
    func startScan() {
        showScanWidget = true
    }
}

struct ContentView: View {
    var body: some View {
        BluetoothScanView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
