//
//  WatchAppCompanionApp.swift
//  WatchAppCompanion Watch App
//
//  Created by ajapps on 2/15/25.
//

import SwiftUI

@main
struct WatchAppCompanion_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
